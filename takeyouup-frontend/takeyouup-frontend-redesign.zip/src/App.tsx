import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/components/ThemeProvider";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import InterviewPrep from "./pages/InterviewPrep";
import InterviewPrepDetail from "./pages/InterviewPrepDetail";
import CourseDetail from "./pages/CourseDetail";
import About from "./pages/About";
import Contact from "./pages/Contact";
import CodeEditor from "./pages/CodeEditor";
import NotFound from "./pages/NotFound";
import { CourseProvider } from "./context/CourseContext";
import Chatbot from "@/components/Chatbot";
import { AuthProvider } from "@/context/AuthContext";
import Login from "./pages/Login";
import Profile from "./pages/Profile";
import Signup from "./pages/SignUp";
import ProtectedRoute from "./routes/ProtectedRoute";
import CodingQuestions from "./pages/CodingQuestions";
import Resources from "./pages/Resources";
import ResourceCategory from "./pages/ResourceCategory";
import ResourceTopic from "./pages/ResourceTopic";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <div className="flex min-h-screen flex-col bg-background text-foreground">
              <Navbar />
              <main className="flex-1">
                <Routes>
                  <Route path="/login" element={<Login />} />
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/signup" element={<Signup />} />
                  <Route
                    path="/"
                    element={
                      <CourseProvider>
                        <Home />
                      </CourseProvider>
                    }
                  />
                  <Route
                    path="/courses"
                    element={
                      <CourseProvider>
                        <Courses />
                      </CourseProvider>
                    }
                  />
                  <Route
                    path="/:courseSlug"
                    element={
                      <ProtectedRoute>
                        <CourseDetail />
                      </ProtectedRoute>
                    }
                  />
                  <Route
                    path="/:courseSlug/:lessonSlug"
                    element={
                      <ProtectedRoute>
                        <CourseDetail />
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/about" element={<About />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/resources" element={<Resources />} />
                  <Route path="/resources/:categorySlug" element={<ResourceCategory />} />
                  <Route path="/resources/:categorySlug/:topicSlug" element={<ResourceTopic />} />
                  <Route path="/online-compiler" element={<CodeEditor />} />
                  <Route
                    path="/problems"
                    element={
                      <ProtectedRoute>
                        <CodingQuestions />
                      </ProtectedRoute>
                    }
                  />
                  <Route path="/interview-prep" element={<InterviewPrep />} />
                  <Route path="/interview-prep/:id" element={<InterviewPrepDetail />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </main>
              <Footer />
              <Chatbot />
            </div>
          </BrowserRouter>
        </TooltipProvider>
      </ThemeProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
