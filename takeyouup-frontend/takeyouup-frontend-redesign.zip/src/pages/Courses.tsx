import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Clock3, Search, SlidersHorizontal, Sparkles, Star, Users } from "lucide-react";
import { useCourses } from "@/context/CourseContext";

const staticCourses = [
  {
    id: 1,
    slug: "data-structures-algorithms",
    title: "Data Structures & Algorithms",
    description: "Master DSA with structured modules, key-point revision, and interview-focused practice tasks.",
    level: "Intermediate",
    duration: "12 weeks",
    students: 1200,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=1200&h=900&fit=crop",
    category: "Placement",
    lessons: 48,
  },
  {
    id: 2,
    slug: "python-programming-masterclass",
    title: "Python Programming Masterclass",
    description: "A beginner-friendly path that helps students build confidence before moving into projects and interviews.",
    level: "Beginner",
    duration: "8 weeks",
    students: 1500,
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=1200&h=900&fit=crop",
    category: "Programming",
    lessons: 36,
  },
  {
    id: 3,
    slug: "java-programming-masterclass",
    title: "Java Programming Masterclass",
    description: "Strengthen OOP, collections, and interview concepts with an advanced but organized learning route.",
    level: "Advanced",
    duration: "10 weeks",
    students: 940,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=1200&h=900&fit=crop",
    category: "Backend",
    lessons: 42,
  },
  {
    id: 4,
    slug: "web-development-masterclass",
    title: "Web Development Masterclass",
    description: "Build modern interfaces and understand full learning flow from HTML foundations to deployment mindset.",
    level: "Intermediate",
    duration: "9 weeks",
    students: 1100,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=1200&h=900&fit=crop",
    category: "Frontend",
    lessons: 38,
  },
  {
    id: 5,
    slug: "machine-learning-masterclass",
    title: "Machine Learning Masterclass",
    description: "Explore ML fundamentals with student-friendly explanations, projects, and concept reinforcement.",
    level: "Advanced",
    duration: "11 weeks",
    students: 680,
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=1200&h=900&fit=crop",
    category: "AI/ML",
    lessons: 40,
  },
  {
    id: 6,
    slug: "system-design-masterclass",
    title: "System Design Masterclass",
    description: "Understand architecture, scalability, and real-world thinking with an interview-aware curriculum.",
    level: "Advanced",
    duration: "7 weeks",
    students: 560,
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1593642532973-d31b6557fa68?w=1200&h=900&fit=crop",
    category: "Architecture",
    lessons: 26,
  },
];

const quickFilters = ["All", "Beginner", "Intermediate", "Advanced"];

const Courses = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedLevel, setSelectedLevel] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const revealRef = useRef<HTMLDivElement>(null);
  const { courses, loading, error } = useCourses();

  useEffect(() => {
    document.title = "Courses | TakeYouUp";
  }, []);

  useEffect(() => {
    const items = revealRef.current?.querySelectorAll(".reveal") ?? [];
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 },
    );

    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, [selectedCategory, selectedLevel, searchTerm]);

  const courseList = Array.isArray(courses) ? courses : [];
  const allCourses = useMemo(() => {
    const source = loading || error || courseList.length === 0 ? staticCourses : courseList;

    return source.map((course: any, index: number) => ({
      id: course.id ?? index,
      slug: course.slug,
      title: course.title,
      description: course.description,
      level: course.level ?? "Intermediate",
      duration: course.duration ?? `${course.modules?.length || 6} modules`,
      students: course.students ?? 400 + index * 90,
      rating: course.rating ?? 4.8,
      image: course.image || staticCourses[index % staticCourses.length].image,
      category: course.category ?? "Programming",
      lessons:
        course.lessons ??
        course.modules?.reduce((count: number, module: any) => count + (module.lessons?.length || 0), 0) ??
        24,
    }));
  }, [courseList, error, loading]);

  const categories = ["All", ...Array.from(new Set(allCourses.map((course) => course.category)))];

  const filteredCourses = useMemo(() => {
    return allCourses.filter((course) => {
      const categoryMatch = selectedCategory === "All" || course.category === selectedCategory;
      const levelMatch = selectedLevel === "All" || course.level === selectedLevel;
      const searchMatch =
        searchTerm.trim() === "" ||
        course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        course.category.toLowerCase().includes(searchTerm.toLowerCase());

      return categoryMatch && levelMatch && searchMatch;
    });
  }, [allCourses, searchTerm, selectedCategory, selectedLevel]);

  const levelPill = (level: string) => {
    if (level === "Beginner") return "pill-green";
    if (level === "Intermediate") return "pill-gold";
    return "pill-orange";
  };

  return (
    <div ref={revealRef} className="min-h-screen">
      <section className="relative overflow-hidden py-20 md:py-24">
        <div className="absolute inset-0 bg-dots opacity-60" />
        <div
          className="absolute left-0 top-8 h-72 w-72 rounded-full animate-blob"
          style={{ background: "radial-gradient(circle, rgba(245,107,42,0.18), transparent 70%)" }}
        />
        <div
          className="absolute right-0 top-10 h-80 w-80 rounded-full animate-blob-2"
          style={{ background: "radial-gradient(circle, rgba(247,193,63,0.2), transparent 70%)" }}
        />

        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6">
          <div className="grid gap-8 lg:grid-cols-[1fr_360px] lg:items-end">
            <div className="reveal">
              <div className="section-tag">Course discovery</div>
              <h1 className="max-w-3xl text-4xl font-bold md:text-6xl">
                Find the right course for <span className="gradient-text">your current stage</span>
              </h1>
              <p className="mt-5 max-w-2xl text-base leading-8 text-muted-foreground md:text-lg">
                The new course catalog is easier to scan, filter, and trust. Students can quickly compare level, duration, lesson count, and outcomes before committing.
              </p>
            </div>

            <div className="reveal rounded-[32px] border p-6 glass-panel">
              <div className="text-sm font-semibold text-foreground">Why this feels more student-friendly</div>
              <div className="mt-5 space-y-4 text-sm leading-7 text-muted-foreground">
                <div className="flex items-start gap-3">
                  <Sparkles className="mt-1 h-4 w-4 flex-shrink-0" style={{ color: "var(--brand-orange)" }} />
                  Easier course comparison with useful metadata visible at first glance.
                </div>
                <div className="flex items-start gap-3">
                  <BookOpen className="mt-1 h-4 w-4 flex-shrink-0" style={{ color: "var(--brand-orange)" }} />
                  Better hierarchy for new learners who need clarity before enrolling.
                </div>
                <div className="flex items-start gap-3">
                  <Users className="mt-1 h-4 w-4 flex-shrink-0" style={{ color: "var(--brand-orange)" }} />
                  A more polished layout that looks credible and welcoming to students.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="reveal rounded-[32px] border bg-card p-5 md:p-6">
            <div className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
              <label className="relative block">
                <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={searchTerm}
                  onChange={(event) => setSearchTerm(event.target.value)}
                  placeholder="Search by course name, skill, or category"
                  className="tyu-input pl-11"
                />
              </label>

              <div className="flex flex-wrap items-center gap-2">
                <div className="inline-flex items-center gap-2 rounded-full bg-muted px-4 py-2 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  Filters
                </div>
                {quickFilters.map((level) => (
                  <button
                    key={level}
                    onClick={() => setSelectedLevel(level)}
                    className="rounded-full px-4 py-2 text-sm font-semibold transition-all"
                    style={{
                      background: selectedLevel === level ? "var(--brand-orange)" : "hsl(var(--muted))",
                      color: selectedLevel === level ? "white" : "hsl(var(--muted-foreground))",
                    }}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 flex flex-wrap gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className="rounded-full border px-4 py-2 text-sm font-medium transition-all"
                  style={{
                    borderColor: selectedCategory === category ? "rgba(245, 107, 42, 0.3)" : "hsl(var(--border))",
                    background: selectedCategory === category ? "rgba(245, 107, 42, 0.1)" : "transparent",
                    color: selectedCategory === category ? "var(--brand-orange)" : "hsl(var(--muted-foreground))",
                  }}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-8 flex items-center justify-between gap-3 text-sm text-muted-foreground">
            <div>
              Showing <span className="font-semibold text-foreground">{filteredCourses.length}</span> courses
            </div>
            <div>Clearer cards, stronger hierarchy, better scanability.</div>
          </div>

          <div className="mt-8 grid gap-6 md:grid-cols-2 xl:grid-cols-3">
            {filteredCourses.map((course, index) => (
              <div key={course.id} className={`reveal delay-${(index % 3) + 1} card-lift overflow-hidden rounded-[30px] border bg-card`}>
                <div className="relative aspect-[16/11] overflow-hidden">
                  <img src={course.image} alt={course.title} className="h-full w-full object-cover transition-transform duration-500 hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent" />
                  <div className="absolute left-5 top-5 flex flex-wrap gap-2">
                    <span className={levelPill(course.level)}>{course.level}</span>
                    <span className="pill-blue">{course.category}</span>
                  </div>
                </div>

                <div className="p-6">
                  <div className="flex flex-wrap gap-4 text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                    <span className="inline-flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" /> {course.duration}</span>
                    <span className="inline-flex items-center gap-1.5"><BookOpen className="h-3.5 w-3.5" /> {course.lessons} lessons</span>
                    <span className="inline-flex items-center gap-1.5"><Users className="h-3.5 w-3.5" /> {course.students.toLocaleString()}</span>
                  </div>

                  <h3 className="mt-4 text-2xl font-bold leading-tight">{course.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-muted-foreground">{course.description}</p>

                  <div className="mt-6 flex items-center justify-between gap-3">
                    <div className="inline-flex items-center gap-1.5 text-sm font-semibold text-amber-500">
                      <Star className="h-4 w-4 fill-current" />
                      {course.rating}
                    </div>
                    <Link to={`/${course.slug}`} className="inline-flex items-center gap-2 text-sm font-bold" style={{ color: "var(--brand-orange)" }}>
                      View details
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="reveal mt-12 rounded-[32px] border p-8 text-center md:p-10" style={{ background: "linear-gradient(135deg, rgba(245,107,42,0.08), rgba(247,193,63,0.08))" }}>
            <h2 className="text-2xl font-bold md:text-3xl">Need a custom path for your students?</h2>
            <p className="mx-auto mt-3 max-w-2xl text-sm leading-7 text-muted-foreground md:text-base">
              The redesigned catalog can easily grow into curated tracks for placements, beginner onboarding, or skill-specific cohorts.
            </p>
            <Link to="/contact" className="btn-orange mt-6">
              Contact us
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Courses;
