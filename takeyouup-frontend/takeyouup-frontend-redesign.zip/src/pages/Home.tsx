import { Link } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  BrainCircuit,
  Briefcase,
  CalendarCheck2,
  CheckCircle2,
  Clock3,
  Code2,
  Compass,
  Gauge,
  PlayCircle,
  Sparkles,
  Star,
  Target,
  Trophy,
  Users,
} from "lucide-react";
import { useCourses } from "@/context/CourseContext";
import { useEffect, useMemo, useRef } from "react";

const fallbackCourses = [
  {
    id: 1,
    title: "Data Structures & Algorithms",
    slug: "data-structures-algorithms",
    description: "Build problem-solving depth with curated modules, revision support, and interview-style practice.",
    level: "Intermediate",
    duration: "12 weeks",
    students: 1200,
    rating: 4.8,
    category: "Placement",
    lessons: 48,
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=1200&h=900&fit=crop",
  },
  {
    id: 2,
    title: "Python Programming Masterclass",
    slug: "python-programming-masterclass",
    description: "Start from basics, build mini projects, and gain confidence for both academics and technical rounds.",
    level: "Beginner",
    duration: "8 weeks",
    students: 1500,
    rating: 4.9,
    category: "Programming",
    lessons: 36,
    image: "https://images.unsplash.com/photo-1526379095098-d400fd0bf935?w=1200&h=900&fit=crop",
  },
  {
    id: 3,
    title: "Java Programming Masterclass",
    slug: "java-programming-masterclass",
    description: "Learn Java with structured lessons, practical examples, and a roadmap that prepares students for interviews.",
    level: "Advanced",
    duration: "10 weeks",
    students: 940,
    rating: 4.7,
    category: "Backend",
    lessons: 42,
    image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=1200&h=900&fit=crop",
  },
];

const learningSignals = [
  {
    icon: Compass,
    title: "Guided Roadmaps",
    description: "Students always know what to learn next, what to revise, and what to practice after each topic.",
  },
  {
    icon: PlayCircle,
    title: "Learn By Doing",
    description: "Courses connect concepts with coding practice, quizzes, and interview-style problem solving.",
  },
  {
    icon: Gauge,
    title: "Progress Friendly",
    description: "Clear milestones, lesson counts, and learning rhythm reduce overwhelm for beginners.",
  },
  {
    icon: Briefcase,
    title: "Career Ready",
    description: "The experience stays focused on placements, confidence building, and job-ready outcomes.",
  },
];

const studentWins = [
  { label: "Structured lessons", value: "120+" },
  { label: "Practice resources", value: "40+" },
  { label: "Learner satisfaction", value: "4.9/5" },
  { label: "Interview tracks", value: "Daily" },
];

const weeklyPlan = [
  "Watch one focused lesson block",
  "Revise key points and module summary",
  "Attempt quiz or coding task",
  "Track what to revisit this weekend",
];

const Home = () => {
  const revealRef = useRef<HTMLDivElement>(null);
  const { courses, loading, error } = useCourses();

  useEffect(() => {
    document.title = "TakeYouUp | Student-first learning management platform";
  }, []);

  useEffect(() => {
    const items = revealRef.current?.querySelectorAll(".reveal") ?? [];
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("in-view");
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.14 },
    );

    items.forEach((item) => observer.observe(item));
    return () => observer.disconnect();
  }, []);

  const courseList = Array.isArray(courses) ? courses : [];

  const displayCourses = useMemo(() => {
    if (loading || error || courseList.length === 0) {
      return fallbackCourses;
    }

    return courseList.slice(0, 3).map((course: any, index: number) => ({
      id: course.id ?? index,
      title: course.title,
      slug: course.slug,
      description: course.description,
      level: course.level ?? "Intermediate",
      duration: course.duration ?? `${course.modules?.length || 6} modules`,
      students: course.students ?? 500 + index * 120,
      rating: course.rating ?? 4.8,
      category: course.category ?? "Programming",
      lessons: course.modules?.reduce((count: number, module: any) => count + (module.lessons?.length || 0), 0) ?? 24,
      image:
        course.image ||
        fallbackCourses[index % fallbackCourses.length].image,
    }));
  }, [courseList, error, loading]);

  const levelPill = (level: string) => {
    if (level === "Beginner") return "pill-green";
    if (level === "Intermediate") return "pill-gold";
    return "pill-orange";
  };

  return (
    <div ref={revealRef}>
      <section className="noise-overlay relative overflow-hidden">
        <div
          className="absolute inset-0 bg-grid opacity-60"
          style={{
            maskImage: "radial-gradient(circle at center, black 35%, transparent 90%)",
          }}
        />
        <div
          className="absolute -left-16 top-8 h-72 w-72 rounded-full animate-blob"
          style={{ background: "radial-gradient(circle, rgba(245,107,42,0.22), transparent 70%)", filter: "blur(14px)" }}
        />
        <div
          className="absolute right-0 top-20 h-80 w-80 rounded-full animate-blob-2"
          style={{ background: "radial-gradient(circle, rgba(247,193,63,0.22), transparent 70%)", filter: "blur(20px)" }}
        />

        <div className="mx-auto grid min-h-[calc(100vh-92px)] max-w-7xl items-center gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:py-24">
          <div className="relative z-10">
            <div className="pill-orange animate-fade-up anim-d0 mb-6 w-fit">
              <Sparkles className="h-3.5 w-3.5" />
              Better learning flow for students
            </div>
            <h1 className="animate-fade-up anim-d1 max-w-3xl text-5xl font-extrabold leading-[0.95] md:text-6xl lg:text-7xl">
              Learn smarter.
              <br />
              Practice daily.
              <br />
              <span className="gradient-text">Grow with confidence.</span>
            </h1>
            <p className="animate-fade-up anim-d2 mt-6 max-w-2xl text-base leading-8 text-muted-foreground md:text-lg">
              TakeYouUp is now shaped around what students actually need: a cleaner interface, guided learning paths, clear course discovery, revision support, and an easier way to move from lessons into practice.
            </p>

            <div className="animate-fade-up anim-d3 mt-8 flex flex-wrap gap-3">
              <Link to="/courses" className="btn-orange">
                Explore Courses
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/resources" className="btn-outline-dark">
                Open Practice Hub
              </Link>
            </div>

            <div className="animate-fade-up anim-d4 mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {studentWins.map((item) => (
                <div key={item.label} className="rounded-3xl border bg-card/80 px-4 py-4 shadow-sm">
                  <div className="text-2xl font-bold" style={{ fontFamily: "'Syne', sans-serif" }}>
                    {item.value}
                  </div>
                  <div className="mt-1 text-sm text-muted-foreground">{item.label}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 reveal in-view">
            <div className="glass-panel rounded-[32px] p-5 md:p-6">
              <div className="grid gap-4 md:grid-cols-[1.1fr_0.9fr]">
                <div className="rounded-[28px] border p-5" style={{ background: "linear-gradient(180deg, rgba(245,107,42,0.1), rgba(255,255,255,0.02))" }}>
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-semibold text-foreground">Student dashboard preview</div>
                      <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">This week</div>
                    </div>
                    <div className="pill-green">
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      On track
                    </div>
                  </div>

                  <div className="rounded-3xl bg-background/85 p-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="font-semibold">Python Fundamentals</span>
                      <span className="text-muted-foreground">68%</span>
                    </div>
                    <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                      <div className="h-full rounded-full" style={{ width: "68%", background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }} />
                    </div>
                    <div className="mt-4 grid gap-3 sm:grid-cols-2">
                      <div className="rounded-2xl bg-muted/60 p-3">
                        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                          <CalendarCheck2 className="h-4 w-4" />
                          Next lesson
                        </div>
                        <div className="mt-1 text-sm text-muted-foreground">Functions and loops</div>
                      </div>
                      <div className="rounded-2xl bg-muted/60 p-3">
                        <div className="flex items-center gap-2 text-sm font-semibold text-foreground">
                          <Target className="h-4 w-4" />
                          Practice goal
                        </div>
                        <div className="mt-1 text-sm text-muted-foreground">Solve 5 coding questions</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-[28px] border bg-card p-5 shadow-sm">
                    <div className="text-sm font-semibold text-foreground">This week&apos;s plan</div>
                    <div className="mt-4 space-y-3">
                      {weeklyPlan.map((item, index) => (
                        <div key={item} className="flex items-start gap-3">
                          <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full text-xs font-bold text-white" style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}>
                            {index + 1}
                          </div>
                          <p className="text-sm leading-6 text-muted-foreground">{item}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-[28px] border bg-[var(--brand-navy)] p-5 text-white shadow-xl">
                    <div className="flex items-center gap-2 text-sm text-white/80">
                      <Trophy className="h-4 w-4 text-yellow-300" />
                      Student momentum
                    </div>
                    <div className="mt-3 text-3xl font-bold">14 day streak</div>
                    <p className="mt-2 text-sm leading-6 text-white/70">
                      Small, consistent progress wins. The new UI keeps goals visible and encourages daily learning rhythm.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="reveal text-center">
            <div className="section-tag justify-center">Why students stay engaged</div>
            <h2 className="text-3xl font-bold md:text-4xl">
              A learning experience that feels <span className="gradient-text">clear, modern, and motivating</span>
            </h2>
          </div>

          <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {learningSignals.map((feature, index) => (
              <div key={feature.title} className={`reveal delay-${(index % 4) + 1} card-lift rounded-[28px] border bg-card p-6`}>
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl text-white" style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}>
                  <feature.icon className="h-5 w-5" />
                </div>
                <h3 className="mt-5 text-xl font-bold">{feature.title}</h3>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20" style={{ background: "hsl(var(--muted) / 0.45)" }}>
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div className="reveal">
              <div className="section-tag">Top courses</div>
              <h2 className="text-3xl font-bold md:text-4xl">Popular learning paths for students</h2>
              <p className="mt-3 max-w-2xl text-sm leading-7 text-muted-foreground md:text-base">
                Discover courses with better structure, useful metadata, and a more welcoming first impression for both beginners and serious learners.
              </p>
            </div>
            <Link to="/courses" className="reveal inline-flex items-center gap-2 text-sm font-bold" style={{ color: "var(--brand-orange)" }}>
              Browse all courses
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid gap-6 lg:grid-cols-3">
            {displayCourses.map((course: any, index: number) => (
              <div key={course.id} className={`reveal delay-${(index % 3) + 1} card-lift overflow-hidden rounded-[30px] border bg-card`}>
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img src={course.image} alt={course.title} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/10 to-transparent" />
                  <div className="absolute left-5 top-5 flex flex-wrap gap-2">
                    <span className={levelPill(course.level)}>{course.level}</span>
                    <span className="pill-blue">{course.category}</span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                    <span className="inline-flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" /> {course.duration}</span>
                    <span className="inline-flex items-center gap-1.5"><BookOpen className="h-3.5 w-3.5" /> {course.lessons} lessons</span>
                    <span className="inline-flex items-center gap-1.5"><Users className="h-3.5 w-3.5" /> {course.students?.toLocaleString()}</span>
                  </div>
                  <h3 className="mt-4 text-2xl font-bold leading-tight">{course.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-muted-foreground">{course.description}</p>

                  <div className="mt-5 flex items-center justify-between">
                    <div className="inline-flex items-center gap-1.5 text-sm font-semibold text-amber-500">
                      <Star className="h-4 w-4 fill-current" />
                      {course.rating}
                    </div>
                    <Link to={`/${course.slug}`} className="inline-flex items-center gap-2 text-sm font-bold" style={{ color: "var(--brand-orange)" }}>
                      Open course
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto grid max-w-7xl gap-6 px-4 sm:px-6 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="reveal rounded-[32px] border bg-card p-7 md:p-8">
            <div className="section-tag">Student toolkit</div>
            <h2 className="text-3xl font-bold md:text-4xl">Everything learners need in one platform</h2>
            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              {[
                { icon: Code2, title: "Coding practice", text: "Move from theory to implementation without leaving the platform." },
                { icon: BrainCircuit, title: "Quizzes and revision", text: "Reinforce lessons with topic checks and key-point reviews." },
                { icon: Trophy, title: "Interview readiness", text: "Students can combine learning with placement-focused preparation." },
                { icon: Target, title: "Focused goals", text: "Clear milestones make the next action obvious instead of overwhelming." },
              ].map((item) => (
                <div key={item.title} className="rounded-3xl bg-muted/55 p-5">
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl text-white" style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}>
                    <item.icon className="h-5 w-5" />
                  </div>
                  <h3 className="mt-4 text-lg font-bold">{item.title}</h3>
                  <p className="mt-2 text-sm leading-7 text-muted-foreground">{item.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="reveal rounded-[32px] border p-7 text-white md:p-8" style={{ background: "linear-gradient(160deg, var(--brand-navy), #0f1222)" }}>
            <div className="section-tag" style={{ color: "#f7c13f" }}>Ready to start</div>
            <h2 className="text-3xl font-bold md:text-4xl">Give students a platform that feels premium and easy to use.</h2>
            <p className="mt-4 text-sm leading-7 text-white/75 md:text-base">
              The refreshed UI puts clarity first, looks more modern, and makes your LMS easier to explore for new students.
            </p>
            <div className="mt-8 space-y-3">
              {[
                "Cleaner landing page with stronger first impression",
                "Student-centric course cards and discovery flow",
                "More guided course detail layout for focused learning",
              ].map((point) => (
                <div key={point} className="flex items-start gap-3 rounded-2xl bg-white/5 px-4 py-3 text-sm text-white/85">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 flex-shrink-0 text-yellow-300" />
                  {point}
                </div>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/courses" className="btn-orange">
                Start exploring
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/contact" className="btn-outline-dark" style={{ color: "white" }}>
                Contact us
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
