import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useMemo, useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  BookOpen,
  BrainCircuit,
  CheckCircle2,
  ChevronRight,
  Clock3,
  FileText,
  Layers3,
  PlayCircle,
  Star,
  Target,
  Users,
} from "lucide-react";
import QuizSection from "@/components/QuizSection";
import api from "@/api/axios";

const CourseDetail = () => {
  const { courseSlug, lessonSlug } = useParams();
  const navigate = useNavigate();
  const [selectedLesson, setSelectedLesson] = useState({ moduleIndex: 0, lessonIndex: 0 });
  const [course, setCourse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Course Details | TakeYouUp";
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login");
      return;
    }

    const fetchCourse = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await api.get(`/courses/slug/${courseSlug}`);
        setCourse(response.data);
      } catch (fetchError: any) {
        setError(fetchError.response?.data?.message || "Failed to fetch course");
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [courseSlug, navigate]);

  useEffect(() => {
    if (!course || !lessonSlug) return;

    for (let moduleIndex = 0; moduleIndex < course.modules.length; moduleIndex += 1) {
      const lessonIndex = course.modules[moduleIndex].lessons.findIndex((lesson: any) => lesson.slug === lessonSlug);
      if (lessonIndex !== -1) {
        setSelectedLesson({ moduleIndex, lessonIndex });
        break;
      }
    }
  }, [course, lessonSlug]);

  const totalLessons = useMemo(
    () => course?.modules?.reduce((count: number, module: any) => count + (module.lessons?.length || 0), 0) ?? 0,
    [course],
  );

  const lessonNumber = useMemo(() => {
    if (!course) return 0;

    let count = 0;
    for (let moduleIndex = 0; moduleIndex < course.modules.length; moduleIndex += 1) {
      for (let lessonIndex = 0; lessonIndex < course.modules[moduleIndex].lessons.length; lessonIndex += 1) {
        count += 1;
        if (moduleIndex === selectedLesson.moduleIndex && lessonIndex === selectedLesson.lessonIndex) {
          return count;
        }
      }
    }

    return 0;
  }, [course, selectedLesson.lessonIndex, selectedLesson.moduleIndex]);

  const completion = totalLessons ? Math.round((lessonNumber / totalLessons) * 100) : 0;

  const currentModule = course?.modules?.[selectedLesson.moduleIndex];
  const currentLesson = currentModule?.lessons?.[selectedLesson.lessonIndex];

  const handleLessonClick = (moduleIndex: number, lessonIndex: number) => {
    const lesson = course.modules[moduleIndex].lessons[lessonIndex];
    setSelectedLesson({ moduleIndex, lessonIndex });
    navigate(lesson.slug ? `/${course.slug}/${lesson.slug}` : `/${course.slug}`);
  };

  const moveToPreviousLesson = () => {
    if (!course) return;

    if (selectedLesson.lessonIndex > 0) {
      handleLessonClick(selectedLesson.moduleIndex, selectedLesson.lessonIndex - 1);
      return;
    }

    if (selectedLesson.moduleIndex > 0) {
      const previousModule = course.modules[selectedLesson.moduleIndex - 1];
      handleLessonClick(selectedLesson.moduleIndex - 1, previousModule.lessons.length - 1);
    }
  };

  const moveToNextLesson = () => {
    if (!course || !currentModule) return;

    if (selectedLesson.lessonIndex < currentModule.lessons.length - 1) {
      handleLessonClick(selectedLesson.moduleIndex, selectedLesson.lessonIndex + 1);
      return;
    }

    if (selectedLesson.moduleIndex < course.modules.length - 1) {
      handleLessonClick(selectedLesson.moduleIndex + 1, 0);
    }
  };

  if (loading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
          <div className="rounded-[30px] border bg-card p-5">
            <Skeleton className="mb-3 h-7 w-40" />
            <Skeleton className="mb-6 h-4 w-28" />
            {Array.from({ length: 7 }).map((_, index) => (
              <Skeleton key={index} className="mb-3 h-11 w-full rounded-2xl" />
            ))}
          </div>
          <div className="space-y-5">
            <div className="rounded-[30px] border bg-card p-6">
              <Skeleton className="mb-4 h-8 w-2/3" />
              <Skeleton className="mb-2 h-4 w-full" />
              <Skeleton className="mb-2 h-4 w-full" />
              <Skeleton className="h-4 w-4/5" />
            </div>
            <div className="rounded-[30px] border bg-card p-6">
              <Skeleton className="mb-3 h-6 w-40" />
              <Skeleton className="mb-2 h-4 w-full" />
              <Skeleton className="mb-2 h-4 w-full" />
              <Skeleton className="h-4 w-5/6" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center px-4 text-center">
        <div className="rounded-[28px] border bg-card px-8 py-10">
          <div className="text-lg font-bold text-red-500">Unable to load course</div>
          <p className="mt-3 text-sm text-muted-foreground">{error}</p>
        </div>
      </div>
    );
  }

  if (!course) {
    return <div className="flex min-h-[60vh] items-center justify-center text-muted-foreground">No course found.</div>;
  }

  const isFirstLesson = selectedLesson.moduleIndex === 0 && selectedLesson.lessonIndex === 0;
  const isLastLesson =
    selectedLesson.moduleIndex === course.modules.length - 1 &&
    selectedLesson.lessonIndex === currentModule.lessons.length - 1;

  return (
    <div className="min-h-screen pb-12">
      <section className="border-b bg-card/80">
        <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
          <Link to="/courses" className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground transition-colors hover:text-orange-500">
            <ArrowLeft className="h-4 w-4" />
            Back to courses
          </Link>

          <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_320px] lg:items-end">
            <div>
              <div className="section-tag">Learning workspace</div>
              <h1 className="max-w-3xl text-4xl font-bold md:text-5xl">{course.title}</h1>
              <p className="mt-4 max-w-3xl text-sm leading-7 text-muted-foreground md:text-base">
                A more guided course experience with clear module navigation, key learning points, and quick access to quizzes.
              </p>
              <div className="mt-6 flex flex-wrap gap-3 text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-2"><Layers3 className="h-3.5 w-3.5" /> {course.modules.length} modules</span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-2"><BookOpen className="h-3.5 w-3.5" /> {totalLessons} lessons</span>
                {course.students ? <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-2"><Users className="h-3.5 w-3.5" /> {course.students.toLocaleString()} learners</span> : null}
                {course.rating ? <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-2 text-amber-500"><Star className="h-3.5 w-3.5 fill-current" /> {course.rating}</span> : null}
              </div>
            </div>

            <div className="rounded-[30px] border bg-background/90 p-5">
              <div className="flex items-center justify-between text-sm">
                <span className="font-semibold">Your course progress</span>
                <span className="text-muted-foreground">{completion}%</span>
              </div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full" style={{ width: `${completion}%`, background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }} />
              </div>
              <div className="mt-4 grid gap-3 text-sm text-muted-foreground sm:grid-cols-2">
                <div className="rounded-2xl bg-muted/60 px-4 py-3">
                  <div className="font-semibold text-foreground">Current lesson</div>
                  <div className="mt-1">{lessonNumber} of {totalLessons}</div>
                </div>
                <div className="rounded-2xl bg-muted/60 px-4 py-3">
                  <div className="font-semibold text-foreground">Recommended next step</div>
                  <div className="mt-1">Read key points and attempt the quiz</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <Tabs defaultValue="lessons" className="space-y-6">
          <TabsList className="h-auto rounded-full bg-muted p-1.5">
            <TabsTrigger value="lessons" className="gap-2 rounded-full px-5 py-2.5 data-[state=active]:bg-white data-[state=active]:text-foreground data-[state=active]:shadow-sm">
              <FileText className="h-4 w-4" /> Lessons
            </TabsTrigger>
            <TabsTrigger value="quiz" className="gap-2 rounded-full px-5 py-2.5 data-[state=active]:bg-white data-[state=active]:text-foreground data-[state=active]:shadow-sm">
              <BrainCircuit className="h-4 w-4" /> Quiz
            </TabsTrigger>
          </TabsList>

          <TabsContent value="lessons">
            <div className="grid gap-6 lg:grid-cols-[360px_1fr]">
              <aside className="space-y-4 lg:sticky lg:top-28 lg:self-start">
                <div className="rounded-[30px] border bg-card p-5">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <div className="text-lg font-bold">Course content</div>
                      <div className="text-xs uppercase tracking-[0.2em] text-muted-foreground">Structured by module</div>
                    </div>
                    <div className="pill-orange">{totalLessons} lessons</div>
                  </div>

                  <ScrollArea className="mt-5 h-[min(70vh,700px)] pr-3">
                    <div className="space-y-5">
                      {course.modules.map((module: any, moduleIndex: number) => (
                        <div key={module.title} className="rounded-[24px] border bg-background/70 p-3">
                          <div className="flex items-start gap-3 px-2 py-2">
                            <div className="flex h-9 w-9 items-center justify-center rounded-2xl text-white" style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}>
                              <Layers3 className="h-4 w-4" />
                            </div>
                            <div>
                              <div className="text-sm font-bold">{module.title}</div>
                              <div className="text-xs text-muted-foreground">{module.lessons.length} lessons</div>
                            </div>
                          </div>

                          <div className="mt-2 space-y-2">
                            {module.lessons.map((lesson: any, lessonIndex: number) => {
                              const isActive = selectedLesson.moduleIndex === moduleIndex && selectedLesson.lessonIndex === lessonIndex;
                              return (
                                <button
                                  key={lesson.slug || `${module.title}-${lesson.title}`}
                                  onClick={() => handleLessonClick(moduleIndex, lessonIndex)}
                                  className="flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition-all"
                                  style={{
                                    background: isActive ? "linear-gradient(135deg, rgba(245,107,42,0.16), rgba(247,193,63,0.14))" : "transparent",
                                    color: isActive ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
                                  }}
                                >
                                  <div
                                    className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full text-xs font-bold"
                                    style={{
                                      background: isActive ? "var(--brand-orange)" : "hsl(var(--muted))",
                                      color: isActive ? "white" : "hsl(var(--muted-foreground))",
                                    }}
                                  >
                                    {lessonIndex + 1}
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <div className="truncate text-sm font-medium">{lesson.title}</div>
                                    <div className="mt-1 inline-flex items-center gap-1 text-xs opacity-75">
                                      <PlayCircle className="h-3.5 w-3.5" />
                                      Read lesson
                                    </div>
                                  </div>
                                  <ChevronRight className="h-4 w-4 flex-shrink-0" />
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </div>
              </aside>

              <div className="space-y-6">
                <div className="rounded-[32px] border bg-card p-6 md:p-8">
                  <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.18em] text-muted-foreground">
                    <span>Module {selectedLesson.moduleIndex + 1}</span>
                    <span className="h-1 w-1 rounded-full bg-muted-foreground" />
                    <span>Lesson {selectedLesson.lessonIndex + 1}</span>
                  </div>
                  <h2 className="mt-4 text-3xl font-bold md:text-4xl">{currentLesson?.title}</h2>
                  <p className="mt-4 text-sm leading-8 text-muted-foreground md:text-base">{currentLesson?.content}</p>

                  <div className="mt-8 grid gap-4 md:grid-cols-3">
                    <div className="rounded-3xl bg-muted/55 p-4">
                      <div className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
                        <Clock3 className="h-4 w-4" />
                        Focus time
                      </div>
                      <div className="mt-2 text-sm text-muted-foreground">10 to 15 minutes for this lesson</div>
                    </div>
                    <div className="rounded-3xl bg-muted/55 p-4">
                      <div className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
                        <Target className="h-4 w-4" />
                        Outcome
                      </div>
                      <div className="mt-2 text-sm text-muted-foreground">Understand the core concept before moving to the next module.</div>
                    </div>
                    <div className="rounded-3xl bg-muted/55 p-4">
                      <div className="inline-flex items-center gap-2 text-sm font-semibold text-foreground">
                        <BookOpen className="h-4 w-4" />
                        Revision tip
                      </div>
                      <div className="mt-2 text-sm text-muted-foreground">Use the key points below as a short recap before practice.</div>
                    </div>
                  </div>
                </div>

                {currentLesson?.keyPoints?.length > 0 && (
                  <div className="rounded-[32px] border bg-card p-6 md:p-8">
                    <h3 className="text-2xl font-bold">Key learning points</h3>
                    <div className="mt-6 space-y-4">
                      {currentLesson.keyPoints.map((point: any, index: number) => (
                        <div key={`${point.point}-${index}`} className="flex items-start gap-4 rounded-3xl bg-muted/45 p-4">
                          <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-2xl" style={{ background: "rgba(245, 107, 42, 0.12)" }}>
                            <CheckCircle2 className="h-5 w-5" style={{ color: "var(--brand-orange)" }} />
                          </div>
                          <div>
                            <div className="font-semibold text-foreground">{point.point}</div>
                            {point.explanation ? <p className="mt-2 text-sm leading-7 text-muted-foreground">{point.explanation}</p> : null}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex flex-col gap-3 sm:flex-row sm:justify-between">
                  <button
                    onClick={moveToPreviousLesson}
                    disabled={isFirstLesson}
                    className="btn-outline-dark justify-center"
                    style={{ opacity: isFirstLesson ? 0.45 : 1, pointerEvents: isFirstLesson ? "none" : "auto" }}
                  >
                    <ArrowLeft className="h-4 w-4" />
                    Previous lesson
                  </button>
                  <button
                    onClick={moveToNextLesson}
                    disabled={isLastLesson}
                    className="btn-orange justify-center"
                    style={{ opacity: isLastLesson ? 0.45 : 1, pointerEvents: isLastLesson ? "none" : "auto" }}
                  >
                    Next lesson
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="quiz">
            <div className="rounded-[32px] border bg-card p-4 md:p-6">
              <QuizSection courseId={course.id} />
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default CourseDetail;
