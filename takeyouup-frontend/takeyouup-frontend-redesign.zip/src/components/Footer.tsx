import { Link } from "react-router-dom";
import { ArrowUpRight, BookOpen, Code2, Github, Linkedin, Mail, Sparkles, Twitter } from "lucide-react";

const footerGroups = {
  Learn: [
    { name: "Courses", path: "/courses" },
    { name: "Interview Prep", path: "/interview-prep" },
    { name: "Practice", path: "/online-compiler" },
    { name: "Problems", path: "/problems" },
  ],
  Student: [
    { name: "Resources", path: "/resources" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ],
};

const Footer = () => {
  return (
    <footer className="mt-auto border-t" style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))" }}>
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <div className="mb-10 rounded-[32px] border p-8 md:p-10" style={{ background: "linear-gradient(135deg, rgba(245,107,42,0.08), rgba(247,193,63,0.08))", borderColor: "rgba(245, 107, 42, 0.16)" }}>
          <div className="flex flex-col gap-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <div className="section-tag">Built for learners</div>
              <h2 className="text-3xl font-bold md:text-4xl">A better student experience from discovery to interview day.</h2>
              <p className="mt-3 max-w-xl text-sm leading-7 text-muted-foreground md:text-base">
                TakeYouUp brings structured courses, practice space, revision resources, and progress-friendly design into one place.
              </p>
            </div>
            <div className="grid gap-3 text-sm text-muted-foreground sm:grid-cols-2">
              <div className="rounded-2xl bg-background/80 px-4 py-3">
                <div className="flex items-center gap-2 font-semibold text-foreground">
                  <Sparkles className="h-4 w-4" style={{ color: "var(--brand-orange)" }} />
                  Guided pathways
                </div>
                <div className="mt-1">Clear next steps, practice loops, and interview-focused preparation.</div>
              </div>
              <div className="rounded-2xl bg-background/80 px-4 py-3">
                <div className="flex items-center gap-2 font-semibold text-foreground">
                  <BookOpen className="h-4 w-4" style={{ color: "var(--brand-orange)" }} />
                  Student support
                </div>
                <div className="mt-1">Content that feels approachable whether the learner is just starting or leveling up.</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid gap-12 md:grid-cols-[1.4fr_repeat(2,minmax(0,1fr))]">
          <div className="space-y-5">
            <Link to="/" className="flex w-fit items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl text-white" style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}>
                <Code2 className="h-5 w-5" />
              </div>
              <div>
                <div className="text-xl font-bold" style={{ fontFamily: "'Syne', sans-serif" }}>
                  TakeYou<span style={{ color: "var(--brand-orange)" }}>Up</span>
                </div>
                <div className="text-xs uppercase tracking-[0.18em] text-muted-foreground">Learning Management Platform</div>
              </div>
            </Link>

            <p className="max-w-md text-sm leading-7 text-muted-foreground">
              Designed to help students learn with confidence, practice regularly, and stay motivated through a more polished, user-friendly interface.
            </p>

            <div className="flex items-center gap-3">
              {[
                { icon: Github, href: "#", label: "GitHub" },
                { icon: Twitter, href: "#", label: "Twitter" },
                { icon: Linkedin, href: "#", label: "LinkedIn" },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  aria-label={label}
                  className="flex h-10 w-10 items-center justify-center rounded-2xl border transition-all hover:-translate-y-1 hover:border-orange-400 hover:text-orange-500"
                  style={{ borderColor: "hsl(var(--border))", color: "hsl(var(--muted-foreground))" }}
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {Object.entries(footerGroups).map(([section, items]) => (
            <div key={section}>
              <h4 className="mb-4 text-xs font-semibold uppercase tracking-[0.22em] text-muted-foreground">{section}</h4>
              <ul className="space-y-3">
                {items.map((item) => (
                  <li key={item.path}>
                    <Link to={item.path} className="group inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-orange-500">
                      {item.name}
                      <ArrowUpRight className="h-3.5 w-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col gap-4 border-t pt-8 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between" style={{ borderColor: "hsl(var(--border))" }}>
          <p style={{ fontFamily: "'DM Mono', monospace" }}>Copyright {new Date().getFullYear()} TakeYouUp. Crafted for a stronger student journey.</p>
          <a href="mailto:info@takeyouup.com" className="inline-flex items-center gap-2 transition-colors hover:text-orange-500" style={{ fontFamily: "'DM Mono', monospace" }}>
            <Mail className="h-3.5 w-3.5" />
            info@takeyouup.com
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
