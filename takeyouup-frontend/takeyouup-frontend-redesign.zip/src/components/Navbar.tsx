import { Link, useLocation, useNavigate } from "react-router-dom";
import { useTheme } from "@/components/ThemeProvider";
import { useState, useEffect, useRef } from "react";
import {
  Moon,
  Sun,
  Code2,
  Menu,
  X,
  User,
  LogOut,
  ChevronDown,
  BookOpen,
  BrainCircuit,
  ChartColumn,
  Languages,
  Target,
  Sparkles,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { resourceCategories } from "@/data/resources";

const resourceIcons = {
  "quantitative-aptitude": BrainCircuit,
  "data-interpretation": ChartColumn,
  "logical-reasoning": Target,
  "verbal-reasoning": Languages,
};

const Navbar = () => {
  const { theme, setTheme } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileResourceOpen, setMobileResourceOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [resourceMenuOpen, setResourceMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const resourceMenuRef = useRef<HTMLDivElement>(null);

  const navLinks = [
    { name: "Courses", path: "/courses" },
    { name: "Interview Prep", path: "/interview-prep" },
    { name: "Practice", path: "/online-compiler" },
    { name: "Problems", path: "/problems" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
      if (resourceMenuRef.current && !resourceMenuRef.current.contains(event.target as Node)) {
        setResourceMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    setDropdownOpen(false);
    setResourceMenuOpen(false);
    setMobileMenuOpen(false);
    setMobileResourceOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) =>
    path === "/" ? location.pathname === path : location.pathname.startsWith(path);

  const isResourcesActive = location.pathname.startsWith("/resources");

  const navItemClass =
    "rounded-full px-4 py-2 text-sm font-medium transition-all duration-200 hover:text-foreground";

  const navItemStyle = (active: boolean) => ({
    fontFamily: "'DM Sans', sans-serif",
    color: active ? "var(--brand-orange)" : "hsl(var(--muted-foreground))",
    background: active ? "rgba(245, 107, 42, 0.1)" : "transparent",
  });

  return (
    <nav
      className="tyu-nav sticky top-0 z-50 w-full border-b transition-all duration-300"
      style={{
        background: scrolled ? "hsl(var(--background) / 0.88)" : "hsl(var(--background) / 0.75)",
        borderColor: scrolled ? "hsl(var(--border))" : "transparent",
      }}
    >
      <div className="mx-auto max-w-7xl px-4 py-3 sm:px-6">
        <div className="flex items-center justify-between gap-4 rounded-full border px-3 py-2 glass-panel">
          <div className="flex items-center gap-3">
            <Link to="/" className="group flex items-center gap-3">
              <div
                className="flex h-11 w-11 items-center justify-center rounded-2xl text-white shadow-lg transition-transform duration-300 group-hover:scale-105"
                style={{ background: "linear-gradient(135deg, var(--brand-orange), var(--brand-gold))" }}
              >
                <Code2 className="h-5 w-5" />
              </div>
              <div>
                <div className="text-lg font-bold leading-none" style={{ fontFamily: "'Syne', sans-serif" }}>
                  TakeYou<span style={{ color: "var(--brand-orange)" }}>Up</span>
                </div>
                <div className="hidden text-[11px] uppercase tracking-[0.22em] text-muted-foreground md:block">
                  Student-first LMS
                </div>
              </div>
            </Link>

            <div className="hidden xl:flex xl:items-center xl:gap-1">
              <Link to="/" className={navItemClass} style={navItemStyle(location.pathname === "/")}>
                Home
              </Link>
              {navLinks.map((link) => (
                <Link key={link.path} to={link.path} className={navItemClass} style={navItemStyle(isActive(link.path))}>
                  {link.name}
                </Link>
              ))}

              <div className="relative" ref={resourceMenuRef}>
                <button
                  type="button"
                  className={navItemClass}
                  style={navItemStyle(isResourcesActive)}
                  onClick={() => setResourceMenuOpen((open) => !open)}
                >
                  <span className="flex items-center gap-1.5">
                    Resources
                    <ChevronDown
                      className="h-4 w-4 transition-transform duration-200"
                      style={{ transform: resourceMenuOpen ? "rotate(180deg)" : "rotate(0deg)" }}
                    />
                  </span>
                </button>

                {resourceMenuOpen && (
                  <div className="absolute right-0 top-full z-50 pt-3">
                    <div className="w-[580px] overflow-hidden rounded-[28px] border glass-panel animate-fade-down">
                      <div className="grid md:grid-cols-[220px_1fr]">
                        <div className="border-r p-6" style={{ borderColor: "hsl(var(--border))", background: "hsl(var(--muted) / 0.45)" }}>
                          <div className="section-tag">Resource Hub</div>
                          <h3 className="text-2xl font-bold">Daily practice made simple</h3>
                          <p className="mt-3 text-sm leading-6 text-muted-foreground">
                            Open aptitude, reasoning, verbal, and data interpretation tracks with ready-to-use topic drills.
                          </p>
                          <Link
                            to="/resources"
                            className="mt-5 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold"
                            style={{ background: "rgba(245, 107, 42, 0.1)", color: "var(--brand-orange)" }}
                          >
                            <Sparkles className="h-4 w-4" />
                            View all resources
                          </Link>
                        </div>
                        <div className="grid gap-2 p-4">
                          {resourceCategories.map((category) => {
                            const Icon = resourceIcons[category.slug as keyof typeof resourceIcons] ?? BookOpen;

                            return (
                              <Link
                                key={category.slug}
                                to={`/resources/${category.slug}`}
                                className="group rounded-2xl border border-transparent px-4 py-3 transition-all hover:border-border hover:bg-muted/45"
                              >
                                <div className="flex items-start gap-3">
                                  <div
                                    className="flex h-11 w-11 items-center justify-center rounded-2xl text-white"
                                    style={{ background: `linear-gradient(135deg, ${category.accent}, var(--brand-orange))` }}
                                  >
                                    <Icon className="h-5 w-5" />
                                  </div>
                                  <div className="min-w-0 flex-1">
                                    <div className="flex items-center justify-between gap-3">
                                      <span className="text-sm font-bold text-foreground">{category.title}</span>
                                      <span className="text-xs text-muted-foreground">{category.topics.length} topics</span>
                                    </div>
                                    <p className="mt-1 text-xs leading-5 text-muted-foreground">{category.description}</p>
                                  </div>
                                </div>
                              </Link>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="rounded-full p-2.5 transition-all hover:bg-muted"
              style={{ color: "hsl(var(--muted-foreground))" }}
            >
              {theme === "dark" ? <Sun className="h-[18px] w-[18px]" /> : <Moon className="h-[18px] w-[18px]" />}
            </button>

            {user ? (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setDropdownOpen((open) => !open)}
                  className="flex items-center gap-2 rounded-full border px-2.5 py-1.5 transition-all hover:border-orange-400"
                  style={{ borderColor: "hsl(var(--border))" }}
                >
                  <img src={user.avatar || "https://i.pravatar.cc/40"} alt="avatar" className="h-8 w-8 rounded-full object-cover" />
                  <span className="hidden max-w-24 truncate text-sm font-medium sm:block">{user.name}</span>
                  <ChevronDown
                    className="h-4 w-4 opacity-50 transition-transform duration-200"
                    style={{ transform: dropdownOpen ? "rotate(180deg)" : "rotate(0deg)" }}
                  />
                </button>

                {dropdownOpen && (
                  <div
                    className="absolute right-0 z-50 mt-3 w-52 rounded-3xl border py-2 animate-fade-down"
                    style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--border))", boxShadow: "var(--shadow-soft)" }}
                  >
                    <div className="border-b px-4 py-3 text-xs uppercase tracking-[0.18em] text-muted-foreground" style={{ borderColor: "hsl(var(--border))" }}>
                      {user.email}
                    </div>
                    <Link to="/profile" className="flex items-center gap-2.5 px-4 py-3 text-sm transition-colors hover:bg-muted" onClick={() => setDropdownOpen(false)}>
                      <User className="h-4 w-4 opacity-60" /> Profile
                    </Link>
                    <button
                      onClick={() => {
                        logout();
                        setDropdownOpen(false);
                        navigate("/login");
                      }}
                      className="flex w-full items-center gap-2.5 px-4 py-3 text-left text-sm transition-colors hover:bg-muted"
                      style={{ color: "var(--brand-orange)" }}
                    >
                      <LogOut className="h-4 w-4" /> Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="hidden items-center gap-2 md:flex">
                <Link to="/signup" className="btn-outline-dark" style={{ padding: "0.8rem 1.25rem" }}>
                  Create account
                </Link>
                <Link to="/login" className="btn-orange" style={{ padding: "0.8rem 1.25rem" }}>
                  Sign in
                </Link>
              </div>
            )}

            <button className="rounded-full p-2.5 transition-colors hover:bg-muted xl:hidden" onClick={() => setMobileMenuOpen((open) => !open)}>
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="mt-3 rounded-[28px] border p-4 glass-panel animate-fade-down xl:hidden">
            <div className="flex flex-col gap-1">
              <Link to="/" className="rounded-2xl px-4 py-3 text-sm font-medium" style={navItemStyle(location.pathname === "/")}>
                Home
              </Link>
              {navLinks.map((link) => (
                <Link key={link.path} to={link.path} className="rounded-2xl px-4 py-3 text-sm font-medium" style={navItemStyle(isActive(link.path))}>
                  {link.name}
                </Link>
              ))}

              <button
                type="button"
                onClick={() => setMobileResourceOpen((open) => !open)}
                className="rounded-2xl px-4 py-3 text-left text-sm font-medium"
                style={navItemStyle(isResourcesActive)}
              >
                <span className="flex items-center justify-between gap-3">
                  Resources
                  <ChevronDown
                    className="h-4 w-4 transition-transform duration-200"
                    style={{ transform: mobileResourceOpen ? "rotate(180deg)" : "rotate(0deg)" }}
                  />
                </span>
              </button>

              {mobileResourceOpen && (
                <div className="rounded-3xl bg-muted/50 p-2">
                  <Link to="/resources" className="block rounded-2xl px-3 py-2 text-sm font-medium text-foreground transition-colors hover:bg-background">
                    All resources
                  </Link>
                  {resourceCategories.map((category) => (
                    <Link
                      key={category.slug}
                      to={`/resources/${category.slug}`}
                      className="block rounded-2xl px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
                    >
                      {category.title}
                    </Link>
                  ))}
                </div>
              )}

              {!user && (
                <div className="mt-2 grid gap-2">
                  <Link to="/signup" className="btn-outline-dark justify-center">
                    Create account
                  </Link>
                  <Link to="/login" className="btn-orange justify-center">
                    Sign in
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
